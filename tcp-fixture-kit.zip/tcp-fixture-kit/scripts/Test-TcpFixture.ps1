[CmdletBinding()]
param(
    [string]$ServerAddress = '10.11.12.13',
    [int]$Port = 19000,
    [int]$RequestLength = 64,
    [string]$RequestFile,
    [string]$ExpectedResponseFile = (Join-Path $PSScriptRoot '..\responses\response.bin'),
    [int]$ConnectTimeoutMs = 5000,
    [int]$IoTimeoutMs = 10000
)

$ErrorActionPreference = 'Stop'

if ($RequestFile) {
    $requestBytes = [System.IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $RequestFile).Path)
}
else {
    if ($RequestLength -lt 32) {
        throw 'RequestLengthは共通ヘッダー長の32バイト以上を指定してください。'
    }
    $requestBytes = New-Object byte[] $RequestLength
    for ($i = 0; $i -lt $requestBytes.Length; $i++) {
        if ($i -lt 32) {
            $requestBytes[$i] = [byte](($i + 1) -band 0xFF)
        }
        else {
            $requestBytes[$i] = [byte]((0xA0 + $i) -band 0xFF)
        }
    }
}

if ($requestBytes.Length -lt 32) {
    throw "要求データが32バイト未満です: $($requestBytes.Length) bytes"
}

if (-not (Test-Path -LiteralPath $ExpectedResponseFile -PathType Leaf)) {
    throw "期待する応答ファイルが見つかりません: $ExpectedResponseFile"
}
$expectedBytes = [System.IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $ExpectedResponseFile).Path)
if ($expectedBytes.Length -le 0) {
    throw '期待する応答ファイルが空です。'
}

$client = [System.Net.Sockets.TcpClient]::new()
$stream = $null

try {
    Write-Host "接続先       : ${ServerAddress}:$Port"
    Write-Host "要求データ長 : $($requestBytes.Length) bytes (header 32 bytes)"
    Write-Host "期待応答長   : $($expectedBytes.Length) bytes"

    $asyncResult = $client.BeginConnect($ServerAddress, $Port, $null, $null)
    if (-not $asyncResult.AsyncWaitHandle.WaitOne($ConnectTimeoutMs)) {
        $client.Close()
        throw "TCP接続タイムアウト (${ConnectTimeoutMs} ms)"
    }
    $client.EndConnect($asyncResult)

    $stream = $client.GetStream()
    $stream.ReadTimeout = $IoTimeoutMs
    $stream.WriteTimeout = $IoTimeoutMs

    # Send the entire test request. The fixture responds as soon as the first 32 bytes arrive.
    $stream.Write($requestBytes, 0, $requestBytes.Length)
    $stream.Flush()
    Write-Host "要求データ送信: $($requestBytes.Length) bytes"

    # Response length is known by the test client; do not read until EOF.
    $actualBytes = New-Object byte[] $expectedBytes.Length
    $offset = 0
    while ($offset -lt $actualBytes.Length) {
        $read = $stream.Read($actualBytes, $offset, $actualBytes.Length - $offset)
        if ($read -le 0) {
            throw "応答受信中に切断されました。受信済み=$offset / 期待=$($actualBytes.Length) bytes"
        }
        $offset += $read
    }

    $stream.Dispose()
    $stream = $null
    $client.Close()
    $client = $null

    $expectedHex = [BitConverter]::ToString($expectedBytes)
    $actualHex = [BitConverter]::ToString($actualBytes)
    Write-Host "応答データ受信: $($actualBytes.Length) bytes"
    Write-Host "応答HEX       : $actualHex"

    if ($actualHex -ne $expectedHex) {
        throw "応答データが期待値と一致しません。`nExpected: $expectedHex`nActual  : $actualHex"
    }

    Write-Host 'PASS: 応答データが期待値と一致しました。クライアント側から切断しました。' -ForegroundColor Green
}
finally {
    if ($stream) { $stream.Dispose() }
    if ($client) { $client.Close() }
}
