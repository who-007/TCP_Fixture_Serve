[CmdletBinding()]
param(
    [string]$SwitchName = 'FixtureSwitch',
    [string]$ListenAddress = '10.11.12.13',
    [int]$ListenPort = 19000,
    [string]$FirewallRuleName = 'TCP Fixture Server 19000',
    [switch]$RemoveSwitch
)

$ErrorActionPreference = 'Stop'

$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = [Security.Principal.WindowsPrincipal]::new($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    throw '管理者権限のPowerShellで実行してください。'
}

Write-Host 'TCP portproxyを削除'
& netsh.exe interface portproxy delete v4tov4 `
    "listenaddress=$ListenAddress" "listenport=$ListenPort" "protocol=tcp" 2>$null | Out-Null

Write-Host 'Firewall規則を削除'
Get-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue |
    Remove-NetFirewallRule -ErrorAction SilentlyContinue

$adapterAlias = "vEthernet ($SwitchName)"
Write-Host "固定IPを削除: $ListenAddress on $adapterAlias"
Get-NetIPAddress -InterfaceAlias $adapterAlias -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -eq $ListenAddress } |
    Remove-NetIPAddress -Confirm:$false -ErrorAction SilentlyContinue

if ($RemoveSwitch) {
    Write-Warning '仮想スイッチを削除します。接続中の仮想マシン等がないことを確認してください。'
    if (Get-Command Get-VMSwitch -ErrorAction SilentlyContinue) {
        Get-VMSwitch -Name $SwitchName -ErrorAction SilentlyContinue |
            Remove-VMSwitch -Force
    }
}

Write-Host 'ネットワーク設定を解除しました。' -ForegroundColor Green
if (-not $RemoveSwitch) {
    Write-Host "仮想スイッチ '$SwitchName' は残しています。削除する場合は -RemoveSwitch を付けてください。"
}
