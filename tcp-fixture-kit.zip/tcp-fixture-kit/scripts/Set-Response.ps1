[CmdletBinding(DefaultParameterSetName = 'Hex')]
param(
    [Parameter(Mandatory = $true, ParameterSetName = 'Hex')]
    [string]$Hex,

    [Parameter(Mandatory = $true, ParameterSetName = 'File')]
    [string]$InputFile,

    [string]$OutputFile = (Join-Path $PSScriptRoot '..\responses\response.bin')
)

$ErrorActionPreference = 'Stop'

$outputFullPath = [System.IO.Path]::GetFullPath($OutputFile)
$outputDirectory = [System.IO.Path]::GetDirectoryName($outputFullPath)
if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) {
    throw "出力先ディレクトリがありません: $outputDirectory"
}

if ($PSCmdlet.ParameterSetName -eq 'Hex') {
    # Accept formats such as "DE AD BE EF", "DE-AD-BE-EF", or "DEADBEEF".
    $normalized = $Hex -replace '^\s*0x', ''
    $normalized = $normalized -replace '(?i)0x', ''
    $normalized = $normalized -replace '[\s,;:-]', ''
    if ($normalized.Length -eq 0 -or ($normalized.Length % 2) -ne 0 -or $normalized -notmatch '^[0-9A-Fa-f]+$') {
        throw 'Hexは2桁単位の16進数で指定してください。例: -Hex "DE AD BE EF"'
    }
    $bytes = New-Object byte[] ($normalized.Length / 2)
    for ($i = 0; $i -lt $bytes.Length; $i++) {
        $bytes[$i] = [Convert]::ToByte($normalized.Substring($i * 2, 2), 16)
    }
}
else {
    $bytes = [System.IO.File]::ReadAllBytes((Resolve-Path -LiteralPath $InputFile).Path)
}

if ($bytes.Length -le 0) {
    throw '空の応答ファイルは設定できません。'
}

$tempPath = Join-Path $outputDirectory ('.response-' + [Guid]::NewGuid().ToString('N') + '.tmp')
try {
    [System.IO.File]::WriteAllBytes($tempPath, $bytes)
    Move-Item -LiteralPath $tempPath -Destination $outputFullPath -Force
}
finally {
    if (Test-Path -LiteralPath $tempPath) {
        Remove-Item -LiteralPath $tempPath -Force -ErrorAction SilentlyContinue
    }
}

Write-Host "応答ファイルを更新しました: $outputFullPath" -ForegroundColor Green
Write-Host "サイズ: $($bytes.Length) bytes"
Write-Host "HEX   : $([BitConverter]::ToString($bytes))"
