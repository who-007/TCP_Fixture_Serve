[CmdletBinding()]
param(
    [string]$ServerAddress = '10.11.12.13',
    [int]$Port = 19000,
    [string]$SwitchName = 'FixtureSwitch'
)

$ErrorActionPreference = 'Stop'
$adapterAlias = "vEthernet ($SwitchName)"

Write-Host '=== 仮想NIC / 固定IP ==='
$ip = Get-NetIPAddress -InterfaceAlias $adapterAlias -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -eq $ServerAddress }
if ($ip) {
    Write-Host "OK: $ServerAddress/$($ip.PrefixLength) on $adapterAlias" -ForegroundColor Green
}
else {
    Write-Warning "固定IP $ServerAddress が $adapterAlias に設定されていません。"
}

Write-Host ''
Write-Host '=== IP Helper ==='
$service = Get-Service -Name iphlpsvc -ErrorAction SilentlyContinue
if ($service -and $service.Status -eq 'Running') {
    Write-Host 'OK: iphlpsvc is Running' -ForegroundColor Green
}
else {
    Write-Warning 'IP Helper(iphlpsvc)が起動していません。'
}

Write-Host ''
Write-Host '=== portproxy設定 ==='
& netsh.exe interface portproxy show v4tov4

Write-Host ''
Write-Host "=== TCP接続確認 ${ServerAddress}:$Port ==="
$result = Test-NetConnection -ComputerName $ServerAddress -Port $Port -InformationLevel Detailed
$result | Select-Object ComputerName, RemoteAddress, RemotePort, InterfaceAlias, SourceAddress, TcpTestSucceeded | Format-List

if (-not $result.TcpTestSucceeded) {
    throw 'TCP接続に失敗しました。Dockerコンテナ起動状態、WSL localhost forwarding、portproxy、Firewallを確認してください。'
}
Write-Host 'TCP接続確認 PASS' -ForegroundColor Green
