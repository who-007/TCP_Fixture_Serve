[CmdletBinding()]
param(
    [string]$SwitchName = 'FixtureSwitch',
    [string]$ListenAddress = '10.11.12.13',
    [int]$ListenPort = 19000,
    [string]$ForwardAddress = '127.0.0.1',
    [int]$ForwardPort = 19000,
    [string]$FirewallRuleName = 'TCP Fixture Server 19000'
)

$ErrorActionPreference = 'Stop'

function Test-IsAdministrator {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = [Security.Principal.WindowsPrincipal]::new($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-IsAdministrator)) {
    throw '管理者権限のPowerShellで実行してください。'
}

if ($ListenPort -lt 1 -or $ListenPort -gt 65535 -or $ForwardPort -lt 1 -or $ForwardPort -gt 65535) {
    throw 'ポート番号は1～65535を指定してください。'
}

if (-not (Get-Command New-VMSwitch -ErrorAction SilentlyContinue)) {
    throw @'
Hyper-V PowerShellモジュール(New-VMSwitch)が見つかりません。
WindowsのエディションとHyper-V管理ツールの導入状態を確認してください。
'@
}

Write-Host "[1/5] Hyper-V Internalスイッチを確認: $SwitchName"
$vmSwitch = Get-VMSwitch -Name $SwitchName -ErrorAction SilentlyContinue
if (-not $vmSwitch) {
    New-VMSwitch -Name $SwitchName -SwitchType Internal | Out-Null
    Write-Host "  作成しました。"
}
else {
    if ([string]$vmSwitch.SwitchType -ne 'Internal') {
        throw "同名の仮想スイッチ '$SwitchName' がInternalではありません。既存設定を確認してください。"
    }
    Write-Host "  既に存在します。"
}

$adapterAlias = "vEthernet ($SwitchName)"
Write-Host "[2/5] Windows側仮想NICを確認: $adapterAlias"
$adapter = $null
for ($i = 0; $i -lt 20 -and -not $adapter; $i++) {
    $adapter = Get-NetAdapter -Name $adapterAlias -ErrorAction SilentlyContinue
    if (-not $adapter) { Start-Sleep -Milliseconds 500 }
}
if (-not $adapter) {
    throw "仮想NIC '$adapterAlias' が見つかりません。Hyper-V仮想スイッチの作成状態を確認してください。"
}

$duplicate = Get-NetIPAddress -AddressFamily IPv4 -IPAddress $ListenAddress -ErrorAction SilentlyContinue |
    Where-Object { $_.InterfaceAlias -ne $adapterAlias }
if ($duplicate) {
    $owners = ($duplicate | ForEach-Object { "$($_.IPAddress) on $($_.InterfaceAlias)" }) -join ', '
    throw "IPアドレス $ListenAddress は別のインターフェースで使用されています: $owners"
}

$currentAddress = Get-NetIPAddress -InterfaceAlias $adapterAlias -AddressFamily IPv4 -ErrorAction SilentlyContinue |
    Where-Object { $_.IPAddress -eq $ListenAddress }
if ($currentAddress -and $currentAddress.PrefixLength -ne 32) {
    $currentAddress | Remove-NetIPAddress -Confirm:$false
    $currentAddress = $null
}
if (-not $currentAddress) {
    New-NetIPAddress -InterfaceAlias $adapterAlias -AddressFamily IPv4 `
        -IPAddress $ListenAddress -PrefixLength 32 | Out-Null
}
Write-Host "  $ListenAddress/32 を設定しました。"

Write-Host '[3/5] IP Helperサービスを確認'
$ipHelper = Get-Service -Name iphlpsvc
if ($ipHelper.Status -ne 'Running') {
    Start-Service -Name iphlpsvc
}

Write-Host "[4/5] TCP portproxyを設定: ${ListenAddress}:${ListenPort} -> ${ForwardAddress}:${ForwardPort}"
# 同一listen address/portの既存ルールがあれば置き換える。
& netsh.exe interface portproxy delete v4tov4 `
    "listenaddress=$ListenAddress" "listenport=$ListenPort" "protocol=tcp" 2>$null | Out-Null
& netsh.exe interface portproxy add v4tov4 `
    "listenaddress=$ListenAddress" "listenport=$ListenPort" `
    "connectaddress=$ForwardAddress" "connectport=$ForwardPort" "protocol=tcp" | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw "netsh portproxyの登録に失敗しました (exit code: $LASTEXITCODE)。IP HelperサービスとIP設定を確認してください。"
}

Write-Host '[5/5] Windows Defender Firewall規則を設定'
Get-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue |
    Remove-NetFirewallRule -ErrorAction SilentlyContinue
New-NetFirewallRule -DisplayName $FirewallRuleName `
    -Direction Inbound -Action Allow -Protocol TCP `
    -LocalAddress $ListenAddress -LocalPort $ListenPort -Profile Any | Out-Null

Write-Host ''
Write-Host 'ネットワーク設定が完了しました。' -ForegroundColor Green
Write-Host "  固定IP       : $ListenAddress/32"
Write-Host "  WebAPI接続先 : ${ListenAddress}:$ListenPort"
Write-Host "  転送先       : ${ForwardAddress}:$ForwardPort"
Write-Host "  仮想NIC      : $adapterAlias"
Write-Host ''
Write-Host '次にWSL2内で docker compose up -d --build を実行し、Test-FixtureNetwork.ps1 で確認してください。'
