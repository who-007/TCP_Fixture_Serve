#!/bin/sh
set -eu

HEADER_BYTES="${HEADER_BYTES:-32}"
RESPONSE_FILE="${RESPONSE_FILE:-/responses/response.bin}"

if [ ! -r "$RESPONSE_FILE" ] || [ ! -s "$RESPONSE_FILE" ]; then
    echo "ERROR: response file is missing, unreadable, or empty: $RESPONSE_FILE" >&2
    exit 2
fi

# Read exactly HEADER_BYTES from stdin and discard the bytes.
# iflag=fullblock makes dd keep reading until the requested block is full
# (or EOF occurs). wc verifies that the complete header arrived.
HEADER_RECEIVED="$(dd iflag=fullblock bs="$HEADER_BYTES" count=1 status=none | wc -c | tr -d '[:space:]')"

if [ "$HEADER_RECEIVED" -ne "$HEADER_BYTES" ]; then
    echo "ERROR: incomplete header: received ${HEADER_RECEIVED}/${HEADER_BYTES} bytes" >&2
    exit 1
fi

# Continue draining the rest of the client request concurrently with the
# response transmission. This prevents unread request bytes from remaining
# in the socket when the client closes after receiving its fixed-size reply.
cat >/dev/null &
DRAIN_PID=$!

# Send the configured binary response. The client knows the expected length.
cat "$RESPONSE_FILE"

# Wait until the client closes its sending side (normally TcpClient.Close/Dispose).
wait "$DRAIN_PID"
