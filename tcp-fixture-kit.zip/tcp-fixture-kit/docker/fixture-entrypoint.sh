#!/bin/sh
set -eu

LISTEN_PORT="${LISTEN_PORT:-9000}"
HEADER_BYTES="${HEADER_BYTES:-32}"
RESPONSE_FILE="${RESPONSE_FILE:-/responses/response.bin}"
IDLE_TIMEOUT="${IDLE_TIMEOUT:-120}"

is_positive_integer() {
    case "$1" in
        ''|*[!0-9]*) return 1 ;;
        0) return 1 ;;
        *) return 0 ;;
    esac
}

is_positive_integer "$LISTEN_PORT" || {
    echo "ERROR: LISTEN_PORT must be a positive integer." >&2
    exit 2
}
is_positive_integer "$HEADER_BYTES" || {
    echo "ERROR: HEADER_BYTES must be a positive integer." >&2
    exit 2
}
is_positive_integer "$IDLE_TIMEOUT" || {
    echo "ERROR: IDLE_TIMEOUT must be a positive integer." >&2
    exit 2
}

if [ ! -r "$RESPONSE_FILE" ] || [ ! -s "$RESPONSE_FILE" ]; then
    echo "ERROR: response file is missing, unreadable, or empty: $RESPONSE_FILE" >&2
    exit 2
fi

export HEADER_BYTES RESPONSE_FILE

echo "TCP fixture listening on 0.0.0.0:${LISTEN_PORT}" >&2
echo "Header bytes: ${HEADER_BYTES}" >&2
echo "Response file: ${RESPONSE_FILE}" >&2
echo "Idle timeout: ${IDLE_TIMEOUT}s" >&2

# -x: HEX dump of traffic; -d -d: connection diagnostics; -T: idle timeout.
# fork: keep the listener alive and handle each connection in a child process.
exec socat -d -d -x -T "$IDLE_TIMEOUT" \
    "TCP4-LISTEN:${LISTEN_PORT},reuseaddr,fork" \
    "EXEC:/usr/local/bin/fixture-session.sh,pipes"
