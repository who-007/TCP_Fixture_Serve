# 02. 構築手順

## 1. Windows側の前提確認

管理者PowerShellでWindowsエディションとHyper-Vコマンドを確認する。

```powershell
Get-ComputerInfo | Select-Object WindowsProductName, WindowsEditionId
Get-Command New-VMSwitch
```

`New-VMSwitch` が見つからない場合は、利用エディションおよびHyper-V管理ツールの導入状態を確認する。

既存ネットワークに `10.11.12.13` が使われていないことも確認する。IPが競合する場合は、本資料の設定値と各スクリプトの既定値を未使用アドレスへ変更する。

## 2. WSL2の確認

Windows PowerShell:

```powershell
wsl -l -v
wsl --version
```

Ubuntu 24.04がVersion 2であることを確認する。

Ubuntu内:

```bash
lsb_release -a
docker version
docker compose version
```

Docker EngineがWSL2 Ubuntu内で動作していることを確認する。

## 3. WSL2ネットワーク設定

本資料はWSL2 NATモードを前提とする。Windowsの `%UserProfile%\.wslconfig` に、既存設定を保持したうえで次を設定する。

```ini
[wsl2]
networkingMode=nat
localhostForwarding=true
```

`localhostForwarding` の既定値はtrue。ファイルを新規作成・編集した場合は次を実行する。

```powershell
wsl --shutdown
```

その後Ubuntuを起動し直す。

## 4. ZIP展開

Ubuntu内で、Windowsのダウンロードフォルダーから展開する例:

```bash
sudo apt-get update
sudo apt-get install -y unzip
cd ~
unzip /mnt/c/Users/<WindowsUser>/Downloads/tcp-fixture-kit.zip
cd ~/tcp-fixture-kit
```

以降はUbuntuの `~/tcp-fixture-kit` で作業する。

## 5. Windowsネットワーク設定

Windows管理者PowerShellから実行する。実行ポリシーで拒否される場合は、PowerShellプロセスだけ一時的にBypassにする。

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Setup-FixtureNetwork.ps1'
```

スクリプトは次を設定する。

- Internal仮想スイッチ `FixtureSwitch`
- 仮想NIC `vEthernet (FixtureSwitch)` の `10.11.12.13/32`
- IP Helperサービス
- `10.11.12.13:19000` → `127.0.0.1:19000` のportproxy
- TCP 19000番のFirewall規則

同名スイッチが存在してもInternalであれば再利用する。IPが別のNICに設定済みの場合は、安全のためエラーにする。

## 6. Dockerコンテナ起動

Ubuntu内:

```bash
cd ~/tcp-fixture-kit
docker compose up -d --build
docker compose ps
docker compose logs --tail=50 tcp-fixture
```

`TCP fixture listening on 0.0.0.0:9000` が表示されることを確認する。

## 7. Windows側の接続試験

通常のPowerShellで実行する。

```powershell
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Test-FixtureNetwork.ps1'
```

TCP接続が失敗する場合は、トラブルシューティング資料を参照する。

## 8. バイナリ送受信試験

```powershell
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Test-TcpFixture.ps1' -RequestLength 64
```

要求64バイトを送信し、デフォルト応答16バイトを受信して期待値と比較する。成功時は `PASS` を表示する。

## 9. .NET側の実装ポイント

- 要求データを送信する。
- 期待する応答長の配列を用意する。
- `NetworkStream.ReadExactlyAsync` などで応答長分を受信する。
- EOFまでReadを繰り返さない。
- 応答受信後に `TcpClient.Close()` または `Dispose()` で切断する。

応答が途中で切断された場合、`ReadExactlyAsync` は `EndOfStreamException` を発生させる。
EOF待ち受信を行うと、クライアントはサーバの切断を待ち、サーバはクライアントの切断を待つため、処理が完了しない。
EOFではなく応答長で完了判定すること。


## 10. .NET 10クライアント処理例

応答サイズが既知の場合の最小例。実際のアプリでは接続先・ポート・応答長を設定値または通信パターンから取得する。

```csharp
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;

public static async Task<byte[]> ExchangeAsync(
    byte[] requestBytes,
    int expectedResponseLength,
    CancellationToken cancellationToken = default)
{
    using var client = new TcpClient();
    await client.ConnectAsync("10.11.12.13", 19000, cancellationToken);

    using NetworkStream stream = client.GetStream();
    await stream.WriteAsync(requestBytes, cancellationToken);

    byte[] responseBytes = new byte[expectedResponseLength];
    await stream.ReadExactlyAsync(responseBytes, cancellationToken);

    // usingのスコープ終了でTcpClientがDisposeされ、クライアントから切断する。
    return responseBytes;
}
```

`ReadExactlyAsync` は期待バイト数に達するまで読み込み、途中でEOFになれば `EndOfStreamException` を発生させる。サーバのFINを待つためにReadを繰り返すのではなく、既知の応答長で受信完了を判定する。
