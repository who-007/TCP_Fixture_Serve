# 05. 検証状況

## 実施した確認

同梱 `docker/fixture-session.sh` をLinux上のsocatで起動し、TCPクライアントからの送受信を確認した。

| 確認項目 | 結果 |
|---|---|
| socat TCP待受 | PASS |
| 32バイトヘッダーを分割送信 | PASS |
| 32バイト目の受信後に応答開始 | PASS |
| 応答バイナリ16バイトの完全受信 | PASS |
| 応答送信中／送信後の後続要求データ読み捨て | PASS |
| クライアントが応答受信後に切断 | PASS |
| socatの接続処理がstatus 0で終了 | PASS |

実施したテストでは、まず16バイト、続いて16バイトを送信し、32バイト到達時に16バイトの固定応答が戻ることを確認した。その後、残り96バイトを送信し、クライアント側からソケットを閉じた。socatログでは応答データが後続96バイトより先に送信され、接続終了処理はstatus 0で終了した。

## 未実施の確認

このパッケージ作成環境では、利用者のWindows 11 / WSL2 / Docker Engine環境にアクセスできないため、以下は未実施。

- Dockerfileの実ビルドとDocker Compose起動
- Windows Hyper-V Internal vSwitchの作成
- Windows仮想NICへのIP設定
- Windows `netsh interface portproxy` の動作
- Windows Defender Firewallの影響確認
- 同梱PowerShellスクリプトのWindows上での実行

したがって、Windows側ネットワークは同梱の `Test-FixtureNetwork.ps1`、TCP送受信は `Test-TcpFixture.ps1` で、実際の利用環境において確認すること。
