# 03. 運用手順

## 1. 起動

Ubuntu 24.04で実行:

```bash
cd ~/tcp-fixture-kit
docker compose up -d
```

初回、Dockerfileやスクリプトを変更した場合:

```bash
docker compose up -d --build
```

## 2. 状態・ログ確認

```bash
docker compose ps
docker compose logs -f tcp-fixture
```

socatのHEXログで、要求データと応答データのバイト列、接続・切断情報を確認する。

## 3. 送受信試験

PowerShell:

```powershell
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Test-TcpFixture.ps1' -RequestLength 64
```

要求サイズを変える:

```powershell
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Test-TcpFixture.ps1' -RequestLength 256
```

既存の要求バイナリファイルを送信する:

```powershell
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Test-TcpFixture.ps1' -RequestFile 'C:\Temp\request.bin'
```

要求ファイルは32バイト以上である必要がある。

## 4. 応答ファイルの変更

HEX指定:

```powershell
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Set-Response.ps1' -Hex 'DE AD BE EF 11 22 33 44'
```

既存ファイル指定:

```powershell
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Set-Response.ps1' -InputFile 'C:\Temp\response.bin'
```

変更後、次の接続から新しい内容を使用する。Composeのマウントは `./responses:/responses:ro` なので、コンテナ内部からは変更できず、ホスト側ファイルだけを更新する。

WebAPI側の応答期待長も新しいファイルの長さに合わせること。

## 5. 停止・再起動

停止:

```bash
docker compose down
```

再起動:

```bash
docker compose restart
```

イメージを再ビルド:

```bash
docker compose up -d --build
```

## 6. Windowsネットワーク設定の解除

管理者PowerShell:

```powershell
& '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Remove-FixtureNetwork.ps1'
```

この操作はportproxy、Firewall規則、固定IPを削除する。Hyper-V Internalスイッチは残す。スイッチも削除する場合だけ `-RemoveSwitch` を付ける。

## 7. 設定変更の注意

- 応答ファイル差し替えだけならコンテナ再起動は不要。
- Composeの環境変数やポート設定変更後は `docker compose up -d` を再実行する。
- Windows固定IP・Windowsポート・転送先ポートを変える場合は、ComposeとPowerShellスクリプト双方の値を一致させる。
- WSL2を `wsl --shutdown` した後は、Docker Engineとコンテナの自動起動設定によっては再起動が必要。Ubuntu内で `docker compose up -d` を実行する。
