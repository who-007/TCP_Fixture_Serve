# 04. トラブルシューティング

## 1. Hyper-Vコマンドが見つからない

症状:

```text
Get-Command New-VMSwitch
```

でコマンドが見つからない。

確認事項:

- WindowsエディションがHyper-V管理機能に対応しているか。
- 「Windowsの機能の有効化または無効化」でHyper-VおよびHyper-V管理ツールが利用可能か。
- 管理者PowerShellで実行しているか。

## 2. 10.11.12.13を設定できない

同じIPアドレスが別のネットワークアダプター、VPN、仮想ネットワークで使用されていないか確認する。

```powershell
Get-NetIPAddress -AddressFamily IPv4 | Sort-Object IPAddress | Format-Table IPAddress,PrefixLength,InterfaceAlias
```

競合する場合は未使用のIPアドレスを選び、Setup/Remove/Test各スクリプトとMinimal API設定を同じ値に変更する。

## 3. Test-NetConnectionが失敗する

次の順番で確認する。

1. Ubuntu内で `docker compose ps` を実行し、コンテナが起動しているか。
2. `docker compose logs tcp-fixture` でsocatが9000番で待ち受けているか。
3. Ubuntu内で `ss -lntp | grep 19000` を実行し、Docker Engineのホストポート公開を確認する。
4. Windowsで `netsh interface portproxy show v4tov4` を実行し、`10.11.12.13:19000 -> 127.0.0.1:19000` があるか。
5. Windowsで `Get-Service iphlpsvc` がRunningか。
6. `%UserProfile%\.wslconfig` のNAT/localhostForwarding設定と、設定変更後の `wsl --shutdown` 実施を確認する。
7. Windows Defender Firewall規則が有効か。

## 4. TCP接続は成功するが応答が返らない

- WebAPIが32バイト以上送信しているか。
- `HEADER_BYTES` が32になっているか。
- `responses/response.bin` が存在し、空でなく、読み取り可能か。
- WebAPIが読み取ろうとしている応答長と、応答ファイルのバイト数が一致しているか。
- クライアントが応答受信前に接続を閉じていないか。

## 5. 応答データを受信できるがWebAPIが完了しない

WebAPIが `ReadAsync` をEOFまで繰り返していないか確認する。本サーバはクライアントの切断を待つため、クライアントがEOFを待つと相互待ちになる。既知の応答バイト数を受信した時点で処理を終了し、クライアント側からClose/Disposeする。

## 6. サーバ側で不完全ヘッダーのログが出る

クライアントが32バイト送信する前に切断したか、送信エラーが発生した可能性がある。socatログとWebAPIログを時刻で照合する。

## 7. socatのタイムアウト

Composeの `IDLE_TIMEOUT` は通信の無通信時間上限（秒）として設定している。テスト時に長時間待機するケースでは値を増やす。変更後:

```bash
docker compose up -d
```

## 8. PowerShellスクリプトをUNCパスから実行できない

実行ポリシーやUNCパス制限の影響を受ける場合は、スクリプトを一時的にWindowsローカルフォルダー（例：`C:\Temp\tcp-fixture-scripts`）へコピーし、管理者PowerShellから実行する。`Test-TcpFixture.ps1` の場合は `-ExpectedResponseFile` にWSL側の `responses\response.bin` のUNCパスを明示する。
