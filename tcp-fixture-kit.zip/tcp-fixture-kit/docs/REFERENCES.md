# 参考資料

本構成の設定・挙動を確認するための公式ドキュメント／man pageです。

1. Microsoft Learn: Hyper-V仮想スイッチの作成と構成
   https://learn.microsoft.com/ja-jp/windows-server/virtualization/hyper-v/get-started/create-a-virtual-switch-for-hyper-v-virtual-machines
2. Microsoft Learn: New-VMSwitch (Hyper-V)
   https://learn.microsoft.com/en-us/powershell/module/hyper-v/new-vmswitch
3. Microsoft Learn: WSLの詳細設定（`.wslconfig`、`localhostForwarding`、`networkingMode`）
   https://learn.microsoft.com/en-us/windows/wsl/wsl-config
4. Microsoft Learn: WSLのWindows/Linuxネットワーク相互運用（localhost forwarding）
   https://learn.microsoft.com/en-us/windows/dev-environment/wsl-interop
5. Microsoft Learn: `netsh interface portproxy`
   https://learn.microsoft.com/en-us/windows-server/networking/technologies/netsh/netsh-interface-portproxy
6. Linux man-pages: `socat(1)`（TCP-LISTEN、fork、EXEC、`-x`、`-T`）
   https://man7.org/linux/man-pages/man1/socat.1.html
7. Docker Docs: Compose networking / published ports
   https://docs.docker.com/compose/how-tos/networking/

このパッケージはWSL2 NATモード、Windows側localhost forwarding有効を前提にしています。WSLやDocker Engineのバージョン、Windowsのネットワークポリシーによって環境差があるため、同梱の疎通確認スクリプトで実機確認してください。
