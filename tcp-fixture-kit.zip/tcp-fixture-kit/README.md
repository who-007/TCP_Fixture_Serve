# TCP治具サーバ（WSL2 Docker / Ubuntu 24.04 LTS）

Windows 11上のASP.NET Core Minimal APIから、外部サーバ代替のTCP治具へ接続し、バイナリ送受信と接続シーケンスを確認するための簡易環境です。

## 1. 仕様の要約

- Windows 11上でMinimal APIがTCPクライアントとして動作する。
- Windows側の接続先は `10.11.12.13:19000` に固定する。
- Windows側の固定IPはHyper-V Internal仮想スイッチの仮想NICに設定する。
- Windowsの `netsh interface portproxy` で `10.11.12.13:19000` を `127.0.0.1:19000` に転送する。
- WSL2 Ubuntu 24.04 LTS内のDocker Engineが、ホスト側 `127.0.0.1:19000` をコンテナのTCP `9000` に公開する。
- コンテナ内のsocatはTCP接続を受け付け、共通ヘッダー32バイトを受信したら応答バイナリを送信する。
- 応答送信と並行して、クライアントからの残りの要求データを読み捨てる。
- WebAPIは既知の応答バイト数を受信したら、自分からTCP接続を閉じる。
- 治具サーバはクライアントからのFINを検知して接続処理を終了する。

## 2. ディレクトリ構成

```text
tcp-fixture-kit/
├── compose.yaml
├── Dockerfile
├── .dockerignore
├── .wslconfig.example
├── README.md
├── docs/
│   ├── 01-basic-design.md
│   ├── 02-installation.md
│   ├── 03-operation.md
│   ├── 04-troubleshooting.md
│   ├── 05-validation.md
│   └── REFERENCES.md
├── docker/
│   ├── fixture-entrypoint.sh
│   └── fixture-session.sh
├── responses/
│   └── response.bin
└── scripts/
    ├── Setup-FixtureNetwork.ps1
    ├── Remove-FixtureNetwork.ps1
    ├── Test-FixtureNetwork.ps1
    ├── Test-TcpFixture.ps1
    └── Set-Response.ps1
```

## 3. 前提条件

- Windows 11。Hyper-Vの仮想スイッチ管理機能が利用できるエディション／構成であること。
- WSL2にUbuntu 24.04 LTSをインストール済み。
- Docker EngineとDocker Compose pluginをUbuntu 24.04内にインストール済み（Docker Desktopは使用しない）。
- WSL2のネットワークはNATモードを前提とする。
- WebAPIが応答の期待バイト数を通信パターンごとに把握しており、そのバイト数を受信した時点でクライアント側から接続を閉じること。

> 注意：`10.11.12.13` がPC内の他のネットワーク、VPN、仮想NICなどで使われていないことを事前に確認してください。必要ならこのIPを一括変更してください。

## 4. 最短セットアップ

### A. ZIPをWSL2のLinuxファイルシステムに展開

WindowsのダウンロードフォルダーにZIPを保存した場合、Ubuntu 24.04で次のように展開します。`<WindowsUser>` はWindowsユーザー名に置き換えてください。

```bash
sudo apt-get update
sudo apt-get install -y unzip
cd ~
unzip /mnt/c/Users/<WindowsUser>/Downloads/tcp-fixture-kit.zip
cd ~/tcp-fixture-kit
```

プロジェクトは `/mnt/c` よりもWSL2のLinuxファイルシステム（例：`/home/<LinuxUser>/tcp-fixture-kit`）に配置することを推奨します。

### B. Windows側の固定IP・ポート転送を設定

管理者権限のPowerShellを開き、必要に応じてこのPowerShellプロセスだけ実行ポリシーを緩和してから、同梱スクリプトを実行します。`<LinuxUser>` はUbuntu内のユーザー名に置き換えてください。

```powershell
Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force
$script = '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Setup-FixtureNetwork.ps1'
& $script
```

このスクリプトは次を設定します。

1. Hyper-V Internal仮想スイッチ `FixtureSwitch` を作成（既存なら再利用）。
2. Windows側仮想NIC `vEthernet (FixtureSwitch)` に `10.11.12.13/32` を設定。
3. IP Helperサービスを起動。
4. `10.11.12.13:19000` から `127.0.0.1:19000` へのTCP portproxyを登録。
5. TCP 19000番のWindows Defender Firewall受信規則を登録。

Hyper-V PowerShellコマンドが利用できない場合は、Windowsのエディションおよび「Hyper-V管理ツール」の有効化状態を確認してください。

### C. WSL2のlocalhost forwardingを確認

Windowsの `%UserProfile%\.wslconfig` を確認します。通常 `localhostForwarding` は既定で有効ですが、この構成では明示しておくと分かりやすくなります。

```ini
[wsl2]
networkingMode=nat
localhostForwarding=true
```

既存の `.wslconfig` がある場合は、他の設定を消さずに `[wsl2]` セクションへ必要な値を追記してください。変更した場合はWindows PowerShellで次を実行し、WSLを再起動します（起動中の全WSLディストリビューションが停止します）。

```powershell
wsl --shutdown
```

### D. Dockerコンテナを起動

Ubuntu 24.04で実行します。

```bash
cd ~/tcp-fixture-kit
docker compose up -d --build
docker compose ps
docker compose logs --tail=50 tcp-fixture
```

ログに次のように表示されれば、TCP待受を開始しています。

```text
TCP fixture listening on 0.0.0.0:9000
Header bytes: 32
Response file: /responses/response.bin
```

### E. Windowsからネットワーク確認

管理者または通常のPowerShellで実行できます。必要に応じて `Set-ExecutionPolicy -Scope Process -ExecutionPolicy Bypass -Force` を実行してください。

```powershell
$script = '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Test-FixtureNetwork.ps1'
& $script
```

`TcpTestSucceeded : True` になれば、Windowsから固定IPへのTCP接続が可能です。

### F. バイナリ送受信テスト

```powershell
$script = '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Test-TcpFixture.ps1'
& $script -RequestLength 64
```

既定では64バイトの要求データ（共通ヘッダー32バイト＋後続32バイト）を送信し、`responses/response.bin` と同じ16バイトの応答を受信・照合します。成功すると `PASS` が表示されます。

## 5. WebAPI側の接続先

```json
{
  "TcpServer": {
    "Host": "10.11.12.13",
    "Port": 19000
  }
}
```

WebAPI側は、要求データを送信した後、通信パターンに対応する応答バイト数を受信してください。応答受信に `ReadExactlyAsync` 等を使用し、EOFまで読み続けないでください。応答データを所定バイト数受信したら `TcpClient.Close()` または `Dispose()` でクライアント側から接続を閉じます。

## 6. 応答バイナリの変更

HEXで指定する場合（PowerShellから実行）：

```powershell
$script = '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Set-Response.ps1'
& $script -Hex '11 22 33 44 AA BB CC DD'
```

ファイルから差し替える場合：

```powershell
& $script -InputFile 'C:\Temp\response.bin'
```

`responses` ディレクトリをコンテナに読み取り専用でマウントしています。ホスト側のファイル差し替えはコンテナ再起動なしで次の接続から反映されます。テスト実行中の同時差し替えは避けてください。

## 7. 停止

Ubuntu 24.04で実行します。

```bash
cd ~/tcp-fixture-kit
docker compose down
```

Windows側の設定を解除する場合は、管理者PowerShellで次を実行します。

```powershell
$script = '\\wsl.localhost\Ubuntu-24.04\home\<LinuxUser>\tcp-fixture-kit\scripts\Remove-FixtureNetwork.ps1'
& $script
```

仮想スイッチ自体も削除する場合だけ `-RemoveSwitch` を付けます。

```powershell
& $script -RemoveSwitch
```

## 8. パラメーター変更

| 変更したい項目 | 変更箇所 |
|---|---|
| Windows固定IP | `Setup-FixtureNetwork.ps1` / `Remove-FixtureNetwork.ps1` / `Test-FixtureNetwork.ps1` の `-ListenAddress` または `-ServerAddress` |
| Windows側ポート | 各PowerShellスクリプトの `-ListenPort` / `-Port` とComposeの左側ポート |
| コンテナ側ポート | Composeの右側ポートと `LISTEN_PORT` |
| 共通ヘッダー長 | Composeの `HEADER_BYTES` |
| 応答ファイル | Composeの `RESPONSE_FILE` |
| 無通信タイムアウト | Composeの `IDLE_TIMEOUT` |

IPまたはポートを変更した場合は、Compose、Setup/Remove/Testの各PowerShellスクリプトで整合を取ってください。

## 9. ログ

```bash
docker compose logs -f tcp-fixture
```

socatの `-x` により、接続ごとの送受信バイト列がHEXで表示されます。`-d -d` により接続・切断などの診断情報も出力されます。

## 10. 検証状況

同梱のセッションスクリプトは、Linux上のsocatを用いて、分割送信された32バイトヘッダー、ヘッダー受信直後の応答送信、後続要求データの読み捨て、クライアント切断後の正常終了を確認しています。Docker Composeのビルド、WSL2、Windows Hyper-V、portproxyおよびPowerShellスクリプトは、利用者のWindows/WSL環境で確認してください。詳細は [docs/05-validation.md](docs/05-validation.md) を参照してください。

## 11. 設計上の重要事項

- TCPはメッセージ境界を保持しません。本構成では「先頭32バイトを共通ヘッダーとして受信した時点」を応答開始条件にします。
- 32バイト以降の要求データは、応答送信と並行して読み捨てます。これは、クライアントが接続を閉じる前に残データを消費し、未読データが残ったままソケットを閉じることによるRSTを避けるためです。
- クライアントは応答バイト数が既知であることを前提に、所定バイト数を受信したら自ら接続を閉じます。
- サーバ側はクライアントのFINを待ちます。クライアント側がEOF待ち受信をすると、双方が待ち続けるため使用しないでください。
- 本構成はローカル単体テスト＋α用の固定応答治具です。要求内容に応じた応答選択、結合テスト用のシナリオ制御などは対象外です。

## 12. 参考資料

公式ドキュメントとsocat man pageの一覧は [docs/REFERENCES.md](docs/REFERENCES.md) を参照してください。
